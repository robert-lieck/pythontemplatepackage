"""
Example
===========================

An example Python file.
"""

# %%
# Some Python Code
# ------------------------
#
# Example code will be executed and shown in the documentation:

print("Hello World")
